package io.topdf.createPDFdocument;

import com.amazon.sct.AppInitializer;
import com.amazon.sct.base.report.utils.MessageActionDetails;
import com.amazon.sct.logger.Logger;
import com.amazon.sct.service.report.generator.utils.ReportResourceManager;
import com.amazon.sct.service.report.generator.utils.costoptimize.blocks.ServerReportParagraph;
import com.amazon.sct.service.report.generator.utils.costoptimize.blocks.ServerReportString;
import com.amazon.sct.service.report.generator.utils.costoptimize.blocks.ServerReportStringBrick;
import com.amazon.sct.util.StringUtils;
import java.awt.Color;
import java.io.IOException;
import java.text.MessageFormat;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.PDPageTree;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.apache.pdfbox.pdmodel.graphics.color.PDColor;
import org.apache.pdfbox.pdmodel.graphics.color.PDDeviceRGB;
import org.apache.pdfbox.pdmodel.interactive.action.PDActionURI;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationLink;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationTextMarkup;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDBorderStyleDictionary;


/**
 * Created by Krupa.D on 10/26/2016.
 */
public class PdfConstants {
    public static final float PDF_GAP = 10;
    public static final float LEFT_INDENT = 40f;
    public static final float HEADER_FONT_SIZE = 14.0f;
    public static final float HEADER_ADDITIONAL_FONT_SIZE = 8.0f;
    public static final float HEADER_16_FONT_SIZE = 16.0f;
    public static final float LINE_INTERVAL = 1.2f;
    public static final float GAP_BETWEEN_PARAGRAPH = 2 * HEADER_FONT_SIZE * LINE_INTERVAL;
    public static final float GAP_BETWEEN_HEADER_AND_TEXT = HEADER_FONT_SIZE * LINE_INTERVAL;
    public static final String EMPTY = "";
    public static final int MAX_LINE_LENGTH = 510;
    public static final int SIMPLE_FONT_SIZE = 10;

    public static final int LEFT_TABLE_CELL_CONTENT_PADDING = 10;
    public static final int TABLE_CELL_FEATURES_WIDTH = 180;
    public static final int TABLE_CELL_DESCRIPTION_WIDTH = 320;
    public static final int TABLE_HEADER_CELL_HEIGHT = 15;
    public static final int TOP_TABLE_CELL_CONTENT_PADDING = 5;
    public static final int LINK_TABLE_CELL_HEIGHT = 30;
    public static final int INFO_TABLE_CELL_HEIGHT = 20;
    public static final int TABLE_FONT_SIZE = 10;


    //The width of the string in 1/1000 units of text space:
    public static final int TEXT_COEFF = 1000;
    public static final float ONE_AND_HALF_INTERVAL = 1.5f;
    public static final float ONE_AND_SEVEN_INTERVAL = 1.7f;
    public static final float ONE_INTERVAL = 1.0f;
    public static final float HALF_INTERVAL = 0.5f;

    private PdfFonts pdfFonts;
    //TODO remove them
    private PDFont basicFont;
    private PDFont basicBoldFont;

    public PdfConstants(PDDocument document) throws IOException {
        loadFonts(document);
    }

    private void loadFonts(PDDocument document) throws IOException {
        basicFont = PDType0Font.load(document, getClass().getResourceAsStream("AmazonEmber_Rg.ttf"));
        basicBoldFont = PDType0Font.load(document, getClass().getResourceAsStream("AmazonEmber_Bd.ttf"));
        this.pdfFonts = new PdfFonts(new AwsPDFont(basicFont.getCOSObject()), new AwsPDFont(basicBoldFont.getCOSObject()));
    }

    public String getFormatIssue(MessageActionDetails sdm) {
        return MessageFormat.format(AppInitializer.resourceBundle.getString("ui.issue.0.1"),
            sdm.getErrorCode(), sdm.getErrorMessage());
    }

    protected String getShortErrorText(String errorText, float textSize) throws IOException {
        if (StringUtils.isNullOrEmpty(errorText)) {
            return "";
        }
        try {
            final float lenOfTxt = ((int) (pdfFonts.getBasic().getStringWidth(errorText)) / 1000f) * textSize;
            final int charLen = (int) ((float) (errorText.length() * (PdfConstants.MAX_LINE_LENGTH / lenOfTxt)));
            return lenOfTxt > PdfConstants.MAX_LINE_LENGTH ? (errorText.substring(0, charLen)) + "..." : errorText;
        } catch (Throwable t) {
            return errorText;
        }
    }

    /**
     * Draws multi line text.
     *
     * @param text      text
     * @param xposition x position
     * @param context   document context
     * @param font      font
     * @param fontSize  font size
     * @throws IOException If an I/O error occurs
     */
    public void drawMultiLineText(String text, float xposition, PdfDocCurrentContext context,
                                  PDFont font, float fontSize) throws IOException {
        //  Logger.UI.writeInfo("drawMultiLineText: len=" + font.getStringWidth(text));

        List<String> listOfLines = new ArrayList<>();

        float lineHeight = formTextLines(text, font, fontSize, listOfLines);
        // and now draw it:
        drawTextLines(xposition, context, font, fontSize, listOfLines, lineHeight);

        listOfLines.clear();
    }

    private float formTextLines(String text, PDFont font, float fontSize, List<String> listOfLines) throws IOException {
        // middle length of string is 100 characters now at a line:
        StringBuilder currentLine = new StringBuilder(100);
        StringBuilder temp = new StringBuilder(100);
        for (String nextWord : text.split(" ")) {
            if (!currentLine.toString().isEmpty()) {
                currentLine.append(" ");
            }
            int nextLineLength = 0;
            try {
                nextLineLength = (int) (fontSize * font.getStringWidth(temp.append(currentLine.toString())
                    .append(nextWord).toString()) / 1000);
            } catch (Throwable th) {
                //if no glyph so write info and continue
                Logger.UI.writeInfo(th.getMessage());
            }
            //     Logger.UI.writeInfo("drawMultiLineText: nextLineLength=" + nextLineLength);
            temp.delete(0, temp.length());
            if (nextLineLength > PdfConstants.MAX_LINE_LENGTH) {
                if (!currentLine.toString().isEmpty()) {
                    listOfLines.add(currentLine.toString());
                }
                currentLine = new StringBuilder(100);
                currentLine.append(getShortErrorText(nextWord, fontSize));
            } else {
                currentLine.append(nextWord);
            }
        }
        //last line add:
        listOfLines.add(currentLine.toString());
        return fontSize * PdfConstants.LINE_INTERVAL;
    }

    private void drawTextLines(float xposition, PdfDocCurrentContext context, PDFont font,
                               float fontSize, List<String> listOfLines, float lineHeight) throws IOException {
        for (String line : listOfLines) {

            context.getPageContentStream().beginText();
            context.getPageContentStream().setFont(font, fontSize);
            context.getPageContentStream().newLineAtOffset(xposition, context.getCurrentNextPositionY());
            try {
                context.getPageContentStream().showText(line);
            } catch (Throwable th) {
                //if no glyph so write info and continue
                Logger.UI.writeInfo(th.getMessage());
            }
            context.getPageContentStream().endText();

            context.setCurrentNextPositionY(context.getCurrentNextPositionY() - lineHeight);
        }
        //remove last appended gap:
        context.setCurrentNextPositionY(context.getCurrentNextPositionY() + lineHeight);
    }

    /**
     * Adds page footer.
     *
     * @param document document
     * @throws IOException if an I/O error occurs
     */
    public void addPageFooter(PDDocument document) throws IOException {
        PDPageContentStream contentStream = null;
        PDPageTree pageList = null;
        try {
            pageList = document.getDocumentCatalog().getPages();
            Iterator<PDPage> it = pageList.iterator();
            int currPageNum = 0;

            while (it.hasNext()) {
                PDPage nextPage = it.next();

                contentStream = new PDPageContentStream(document, nextPage, PDPageContentStream.AppendMode.APPEND, true);

                contentStream.beginText();
                contentStream.setFont(pdfFonts.getBasic(), 8);
                contentStream.newLineAtOffset((PDRectangle.A4.getUpperRightX() - 80), (PDRectangle.A4.getLowerLeftY()) + 20);
                contentStream.showText(
                    MessageFormat.format(
                        AppInitializer.resourceBundle.getString("ui.pdf.report.page.of"),
                        "" + (++currPageNum),
                        "" + pageList.getCount()));
                contentStream.endText();
                contentStream.close();
            }
        } catch (Exception exception) {
            Logger.UI.writeError(exception);
            throw exception;
        } finally {
            if (contentStream != null) {
                try {
                    contentStream.close();
                } catch (IOException ioe) {
                    Logger.UI.writeError(ioe);
                    //nothing
                }
            }
//            if (pageList != null) {
//                pageList.clear();
//            }
        }
    }

    /**
     * Creates text section.
     *
     * @param paragraphList         list of paragraphs
     * @param sectionHeader         section header
     * @param context               document context
     * @param postfixEmptyLineCount counter of empty lines
     * @throws IOException if an I/O error occurs
     */
    public void createTextSection(List<String> paragraphList, String sectionHeader,
                                  PdfDocCurrentContext context, int postfixEmptyLineCount) throws IOException {
        drawMultiLineText(sectionHeader, PdfConstants.LEFT_INDENT, context, pdfFonts.getBold(), PdfConstants.HEADER_16_FONT_SIZE);

        for (String par : paragraphList) {
            if (par != null) {
                context.setCurrentNextPositionY(context.getCurrentNextPositionY() - PdfConstants.GAP_BETWEEN_HEADER_AND_TEXT);
                drawMultiLineText(par, PdfConstants.LEFT_INDENT, context, pdfFonts.getBasic(), SIMPLE_FONT_SIZE);
            }
        }
        context.setCurrentNextPositionY(context.getCurrentNextPositionY()
            - (postfixEmptyLineCount < 0 ? 0 : postfixEmptyLineCount) * PdfConstants.GAP_BETWEEN_PARAGRAPH);
    }

    /**
     * Creates text section.
     *
     * @param paragraphList         list of paragraphs
     * @param sectionHeader         section header
     * @param context               document context
     * @param postfixEmptyLineCount counter of empty lines
     * @param headerSize            header size
     * @throws IOException if an I/O error occurs
     */
    public void createTextSection(List<String> paragraphList, String sectionHeader,
                                  PdfDocCurrentContext context, int postfixEmptyLineCount, float headerSize) throws IOException {
        context.getPageContentStream().beginText();
        context.getPageContentStream().setFont(pdfFonts.getBasic(), headerSize);
        context.getPageContentStream().newLineAtOffset(PdfConstants.LEFT_INDENT, context.getCurrentNextPositionY());
        context.getPageContentStream().showText(sectionHeader);
        context.getPageContentStream().endText();
        for (String par : paragraphList) {
            context.setCurrentNextPositionY(context.getCurrentNextPositionY() - PdfConstants.GAP_BETWEEN_HEADER_AND_TEXT);
            drawMultiLineText(par, PdfConstants.LEFT_INDENT, context, pdfFonts.getBasic(), SIMPLE_FONT_SIZE);
        }
        context.setCurrentNextPositionY(context.getCurrentNextPositionY()
            - (postfixEmptyLineCount < 0 ? 0 : postfixEmptyLineCount) * PdfConstants.GAP_BETWEEN_PARAGRAPH);
    }


    public void createTextFlowSection(ServerReportParagraph paragraph, String sectionHeader,
                                      PdfDocCurrentContext context, int postfixEmptyLineCount) throws IOException {
        if (paragraph == null) {
            return;
        }

        mergeHardwareConfigurationTables(paragraph);
        if (sectionHeader != null) {
            drawMultiLineText(sectionHeader, PdfConstants.LEFT_INDENT, context, pdfFonts.getBold(), PdfConstants.HEADER_16_FONT_SIZE);
        }
        int tableCellIndex = 0;
        label:
        for (ServerReportString string : paragraph) {
            if (string != null && !string.isEmpty()) {
                //if string must be a table section - draw it and go to next iteration
                if (string.getDetails() != null && !string.getDetails().isEmpty()) {
                    drawTables(paragraph, context, string);
                    continue;
                }
                //if string is't table
                context.setCurrentNextPositionY(context.getCurrentNextPositionY() - PdfConstants.GAP_BETWEEN_HEADER_AND_TEXT);
                boolean isFirstBrick = true;
                float lineWidth = 0;
                float xposition = PdfConstants.LEFT_INDENT;
                List<ServerReportStringBrick> words = new LinkedList<>();
                for (ServerReportStringBrick brick : string) {
                    if (brick != null && !brick.isEmpty()) {
                        if (brick.isLink() && !StringUtils.isNullOrEmpty(brick.getMessage())
                            && !StringUtils.isNullOrEmpty(brick.getLink())) {
                            words.add(brick);
                        }
                        if (!brick.isLink() && !StringUtils.isNullOrEmpty(brick.getMessage()) && !brick.getMessage().equals("\n")) {
                            for (String str : brick.getMessage().split(" ")) {
                                words.add(new ServerReportStringBrick(str));
                            }
                        }
                    }
                }
                for (ServerReportStringBrick brick : words) {
                    if (brick.isEmpty() || StringUtils.isNullOrEmpty(brick.getMessage())
                        || (brick.isLink() && StringUtils.isNullOrEmpty(brick.getLink()))) {
                        continue;
                    }
                    if (!isFirstBrick) {
                        if (lineWidth + getWidthOfText(SIMPLE_FONT_SIZE, " ") > MAX_LINE_LENGTH) {
                            xposition = PdfConstants.LEFT_INDENT;
                            lineWidth = 0;
                            context.setCurrentNextPositionY(context.getCurrentNextPositionY()
                                - PdfConstants.LINE_INTERVAL * SIMPLE_FONT_SIZE);
                        } else {
                            lineWidth += getWidthOfText(SIMPLE_FONT_SIZE, " ");
                            xposition += getWidthOfText(SIMPLE_FONT_SIZE, " ");
                            correctYPosition(context, SIMPLE_FONT_SIZE, xposition);
                            drawMultiLineText(" ", xposition, context, pdfFonts.getBasic(), SIMPLE_FONT_SIZE);
                        }
                    }
                    if (lineWidth + getWidthOfText(SIMPLE_FONT_SIZE, brick.getMessage()) > MAX_LINE_LENGTH) {
                        xposition = PdfConstants.LEFT_INDENT;
                        lineWidth = 0;
                        context.setCurrentNextPositionY(context.getCurrentNextPositionY() - PdfConstants.LINE_INTERVAL * SIMPLE_FONT_SIZE);
                    }
                    if (brick.isLink()) {
                        correctYPosition(context, SIMPLE_FONT_SIZE, xposition);
                        if (words.indexOf(brick) == 0) {
                            if (tableCellIndex == 0) {
                                context.setCurrentNextPositionY(context.getCurrentNextPositionY() + PDF_GAP);
                                createTableHeaderForFeatures(context);
                                context.setCurrentNextPositionY(context.getCurrentNextPositionY() - PDF_GAP * 3);
                            }
                            if (words.size() == 3 && words.get(1).getMessage().equals("/") && words.get(2).isLink()) {
                                createTextFlowLink(context, new ArrayList<>(words), xposition,
                                    false, true, tableCellIndex);
                            } else {
                                createTextFlowLink(context, Collections.singletonList(brick), xposition,
                                    false, true, tableCellIndex);
                            }
                            float height = getHeightOfText(sliceText(createStringFromBricks(brick.getListOfDescription()), TABLE_FONT_SIZE,
                                TABLE_CELL_DESCRIPTION_WIDTH - LEFT_TABLE_CELL_CONTENT_PADDING * 2).size(), TABLE_FONT_SIZE) + TOP_TABLE_CELL_CONTENT_PADDING * 4;
                            context.setCurrentNextPositionY(context.getCurrentNextPositionY() - height + TOP_TABLE_CELL_CONTENT_PADDING * 4);
                            tableCellIndex++;
                            continue label;
                        } else {
                            createTextFlowLink(context, Collections.singletonList(brick), xposition, false, false, tableCellIndex);
                        }
                    }
                    if (!brick.isLink()) {
                        correctYPosition(context, SIMPLE_FONT_SIZE, xposition);
                        drawMultiLineText(brick.getMessage(), xposition, context, pdfFonts.getBasic(), SIMPLE_FONT_SIZE);
                    }

                    lineWidth += getWidthOfText(SIMPLE_FONT_SIZE, brick.getMessage());
                    xposition += getWidthOfText(SIMPLE_FONT_SIZE, brick.getMessage());

                    if (brick.getMessage().contains("\n")) {
                        lineWidth = MAX_LINE_LENGTH;
                    }

                    if (isFirstBrick) {
                        isFirstBrick = false;
                    }
                }
                context.setCurrentNextPositionY(context.getCurrentNextPositionY() - PdfConstants.LINE_INTERVAL * SIMPLE_FONT_SIZE);
                tableCellIndex = 0;
            }
        }

        context.setCurrentNextPositionY(context.getCurrentNextPositionY()
            - (postfixEmptyLineCount < 0 ? 0 : postfixEmptyLineCount) * PdfConstants.GAP_BETWEEN_PARAGRAPH);
    }

    private void drawTables(ServerReportParagraph paragraph, PdfDocCurrentContext context, ServerReportString string) throws IOException {
        if (!string.isMerged()) {
            for (Map.Entry<String, Map<String, String>> entry : string.getDetails().entrySet()) {
                if (paragraph.indexOf(string) == paragraph.size() - 1
                    && entry.getKey().split(" ").length > 5) {
                    drawOperationsTable(context, string);
                } else {
                    drawInfoTable(context, entry.getKey(), entry.getValue());
                }
            }
        }
    }

    private void createTextFlowLink(PdfDocCurrentContext context, List<ServerReportStringBrick> linkList, float horizontalIndent,
                                    boolean newLined, boolean wrap, int tableCellIndex) throws IOException {

        float leftIndent = horizontalIndent;
        for (ServerReportStringBrick linkBrick : linkList) {
            if (linkList.indexOf(linkBrick) == 0) {
                if (newLined) {
                    context.setCurrentNextPositionY(context.getCurrentNextPositionY() - PdfConstants.GAP_BETWEEN_HEADER_AND_TEXT);
                }
                if (wrap) {
                    createLinkTableCell(context, tableCellIndex, linkBrick.getListOfDescription());
                }
            }
            if (linkBrick.isLink()) {
                context.getPageContentStream().beginText();
                if (wrap) {
                    context.getPageContentStream().newLineAtOffset(leftIndent + LEFT_TABLE_CELL_CONTENT_PADDING, context.getCurrentNextPositionY());
                } else {
                    context.getPageContentStream().newLineAtOffset(leftIndent, context.getCurrentNextPositionY());
                }
                context.getPageContentStream().setNonStrokingColor(Color.BLUE);
                context.getPageContentStream().setFont(getPdfFonts().getBasic(), SIMPLE_FONT_SIZE);
                if (!wrap) {
                    context.getPageContentStream().showText(linkBrick.getMessage());
                } else {
                    context.getPageContentStream().showText(linkBrick.getMessage());
                }
                PDRectangle pdRectangle = new PDRectangle();
                if (wrap) {
                    pdRectangle.setLowerLeftX(leftIndent + LEFT_TABLE_CELL_CONTENT_PADDING);
                    pdRectangle.setUpperRightX(leftIndent + LEFT_TABLE_CELL_CONTENT_PADDING + getWidthOfText(SIMPLE_FONT_SIZE, linkBrick.getMessage()));
                } else {
                    pdRectangle.setLowerLeftX(leftIndent);
                    pdRectangle.setUpperRightX(leftIndent + getWidthOfText(SIMPLE_FONT_SIZE, linkBrick.getMessage()));
                }
                pdRectangle.setLowerLeftY(context.getCurrentNextPositionY() + 10f);
                pdRectangle.setUpperRightY(context.getCurrentNextPositionY() - 1f);
                PDBorderStyleDictionary borderULine = new PDBorderStyleDictionary();
                borderULine.setStyle(PDBorderStyleDictionary.STYLE_UNDERLINE);
                PDAnnotationLink txtLink = new PDAnnotationLink();
                txtLink.setBorderStyle(borderULine);
                PDColor blue = new PDColor(new float[] {0, 0, 1}, PDDeviceRGB.INSTANCE);

                PDAnnotationTextMarkup txtMark = new PDAnnotationTextMarkup(
                    PDAnnotationTextMarkup.SUB_TYPE_HIGHLIGHT);
                txtMark.setColor(blue);

                PDActionURI action = new PDActionURI();
                action.setURI(linkBrick.getLink());
                txtLink.setAction(action);
                txtLink.setRectangle(pdRectangle);

                context.getCurrentPage().getAnnotations().add(txtLink);
                context.getPageContentStream().setNonStrokingColor(Color.BLACK);
                context.getPageContentStream().endText();
            } else {
                fillSimpleCell(context, leftIndent + LEFT_TABLE_CELL_CONTENT_PADDING, context.getCurrentNextPositionY(),
                    linkBrick.getMessage(), Color.BLACK, SIMPLE_FONT_SIZE);
            }
            leftIndent += getWidthOfText(SIMPLE_FONT_SIZE, linkBrick.getMessage());
        }
    }

    private void drawOperationsTable(PdfDocCurrentContext context, ServerReportString string) throws IOException {
        Map.Entry<String, Map<String, String>> entry = string.getDetails().entrySet().iterator().next();
        context.setCurrentNextPositionY(context.getCurrentNextPositionY() - INFO_TABLE_CELL_HEIGHT);
        drawMultiLineText(entry.getKey(), LEFT_INDENT, context, getPdfFonts().getBasic(), SIMPLE_FONT_SIZE);
        createSimpleTable(context, entry.getValue());
    }

    private void drawInfoTable(PdfDocCurrentContext context, String name, Map<String, String> values) throws IOException {
        context.setCurrentNextPositionY(context.getCurrentNextPositionY() - INFO_TABLE_CELL_HEIGHT);
        drawMultiLineText(name, LEFT_INDENT, context, getPdfFonts().getBold(), SIMPLE_FONT_SIZE);
        createSimpleTable(context, values);
    }

    private void createSimpleTable(PdfDocCurrentContext context, Map<String, String> values) throws IOException {
        float eachElementsWidth = 500.0f / values.size();
        int index = 0;
        float headerHeight = INFO_TABLE_CELL_HEIGHT;
        float contentHeight = INFO_TABLE_CELL_HEIGHT;

        for (Map.Entry<String, String> pair : values.entrySet()) {
            String key = pair.getKey();
            String value = pair.getValue();
            if (getWidthOfText(TABLE_FONT_SIZE, key) > eachElementsWidth - LEFT_TABLE_CELL_CONTENT_PADDING * 2) {
                headerHeight = INFO_TABLE_CELL_HEIGHT * 2;
            }
            if (getWidthOfText(TABLE_FONT_SIZE, value) > eachElementsWidth - LEFT_TABLE_CELL_CONTENT_PADDING * 2) {
                contentHeight = INFO_TABLE_CELL_HEIGHT * 2;
            }
        }

        if (context.getCurrentNextPositionY() < contentHeight + headerHeight + PDF_GAP * 2) {
            context.setCurrentNextPositionY(context.getCurrentNextPositionY() - (contentHeight + headerHeight + PDF_GAP * 2));
        }

        context.setCurrentNextPositionY(context.getCurrentNextPositionY() - PDF_GAP * 2);
        for (Map.Entry<String, String> pair : values.entrySet()) {
            //header
            createSimpleCell(context, LEFT_INDENT + index * eachElementsWidth,
                context.getCurrentNextPositionY() - headerHeight + PDF_GAP,
                eachElementsWidth, headerHeight, 156, 194, 229);
            fillSimpleCell(context,
                LEFT_INDENT + (index * eachElementsWidth),
                context.getCurrentNextPositionY() - TOP_TABLE_CELL_CONTENT_PADDING,
                pair.getKey(), Color.WHITE, TABLE_FONT_SIZE, eachElementsWidth - LEFT_TABLE_CELL_CONTENT_PADDING * 2);


            float topPaddingContent = (contentHeight == INFO_TABLE_CELL_HEIGHT) ? 0.0f : 20.0f;
            //content
            createSimpleCell(context, LEFT_INDENT + index * eachElementsWidth,
                context.getCurrentNextPositionY() - PDF_GAP - headerHeight - topPaddingContent,
                eachElementsWidth, contentHeight, 222, 234, 246);
            fillSimpleCell(context, LEFT_INDENT + index * eachElementsWidth,
                context.getCurrentNextPositionY() - TOP_TABLE_CELL_CONTENT_PADDING - headerHeight,
                pair.getValue(), Color.BLACK, TABLE_FONT_SIZE, eachElementsWidth - LEFT_TABLE_CELL_CONTENT_PADDING * 2);
            index++;
        }
        context.setCurrentNextPositionY(context.getCurrentNextPositionY()
            - headerHeight - contentHeight + PDF_GAP);
    }

    private void createTableHeaderForFeatures(PdfDocCurrentContext context) throws IOException {
        //feature
        createSimpleCell(context, LEFT_INDENT, context.getCurrentNextPositionY() - PDF_GAP,
            TABLE_CELL_FEATURES_WIDTH, TABLE_HEADER_CELL_HEIGHT, 156, 194, 229);

        fillSimpleCell(context, LEFT_INDENT + LEFT_TABLE_CELL_CONTENT_PADDING,
            context.getCurrentNextPositionY() - TOP_TABLE_CELL_CONTENT_PADDING,
            ReportResourceManager.getString("ui.server.level.report.pdf.feature.name.unavailable.feature"),
            Color.WHITE, TABLE_FONT_SIZE);

        //description
        createSimpleCell(context, LEFT_INDENT + TABLE_CELL_FEATURES_WIDTH,
            context.getCurrentNextPositionY() - PDF_GAP, TABLE_CELL_DESCRIPTION_WIDTH,
            TABLE_HEADER_CELL_HEIGHT, 156, 194, 229);

        fillSimpleCell(context, LEFT_INDENT + TABLE_CELL_FEATURES_WIDTH + LEFT_TABLE_CELL_CONTENT_PADDING,
            context.getCurrentNextPositionY() - TOP_TABLE_CELL_CONTENT_PADDING,
            ReportResourceManager.getString("ui.server.level.report.pdf.feature.name.description"),
            Color.WHITE, TABLE_FONT_SIZE);
    }


    private void createLinkTableCell(PdfDocCurrentContext context, int tableCellIndex, List<ServerReportStringBrick> description) throws IOException {
        if (description != null) {
            float height = getHeightOfText(sliceText(createStringFromBricks(description), TABLE_FONT_SIZE,
                TABLE_CELL_DESCRIPTION_WIDTH - LEFT_TABLE_CELL_CONTENT_PADDING * 2).size(), TABLE_FONT_SIZE) + TOP_TABLE_CELL_CONTENT_PADDING * 4;
            if (context.getCurrentNextPositionY() < height + PDF_GAP * 2) {
                context.setCurrentNextPositionY(context.getCurrentNextPositionY() - (height + PDF_GAP * 2));
                context.setCurrentNextPositionY(context.getCurrentNextPositionY() - (PDF_GAP * 2));
            } else if (context.getCurrentNextPositionY() > 800) {
                context.setCurrentNextPositionY(context.getCurrentNextPositionY() - (PDF_GAP * 2));
            }
            if (tableCellIndex % 2 == 0) {
                createSimpleCell(context, LEFT_INDENT, context.getCurrentNextPositionY() - height + TOP_TABLE_CELL_CONTENT_PADDING * 4,
                    TABLE_CELL_FEATURES_WIDTH, height, 222, 234, 246);
                createSimpleCell(context, LEFT_INDENT + TABLE_CELL_FEATURES_WIDTH, context.getCurrentNextPositionY() - height + TOP_TABLE_CELL_CONTENT_PADDING * 4,
                    TABLE_CELL_DESCRIPTION_WIDTH, height, 222, 234, 246);
            } else if (tableCellIndex % 2 == 1) {
                createSimpleCell(context, LEFT_INDENT, context.getCurrentNextPositionY() - height + TOP_TABLE_CELL_CONTENT_PADDING * 4,
                    TABLE_CELL_FEATURES_WIDTH, height, 255, 255, 255);
                createSimpleCell(context, LEFT_INDENT + TABLE_CELL_FEATURES_WIDTH, context.getCurrentNextPositionY() - height + TOP_TABLE_CELL_CONTENT_PADDING * 4,
                    TABLE_CELL_DESCRIPTION_WIDTH, height, 255, 255, 255);
            }
            createTableCellDescriptionText(context, description);
        }
    }

    private void createTableCellDescriptionText(PdfDocCurrentContext context, List<ServerReportStringBrick> description) throws IOException {
        List<String> lines = sliceText(createStringFromBricks(description), TABLE_FONT_SIZE,
            TABLE_CELL_DESCRIPTION_WIDTH - LEFT_TABLE_CELL_CONTENT_PADDING * 2);
        if (lines.size() == 1) {
            fillSimpleCell(context, LEFT_INDENT + TABLE_CELL_FEATURES_WIDTH + LEFT_TABLE_CELL_CONTENT_PADDING,
                context.getCurrentNextPositionY() + 2, lines.get(0), Color.BLACK, TABLE_FONT_SIZE);
        } else {
            for (int i = 0; i < lines.size(); i++) {
                fillSimpleCell(context, LEFT_INDENT + TABLE_CELL_FEATURES_WIDTH + LEFT_TABLE_CELL_CONTENT_PADDING,
                    context.getCurrentNextPositionY() - (i * 12) + 2,
                    lines.get(i), Color.BLACK, TABLE_FONT_SIZE);
            }
        }

    }

    private String createStringFromBricks(List<ServerReportStringBrick> bricks) {
        StringBuilder sb = new StringBuilder();
        for (ServerReportStringBrick br : bricks) {
            sb.append(br.getMessage());
            if (br.getMessage().equals(System.lineSeparator())) {
                continue;
            }
            if (bricks.indexOf(br) < bricks.size() - 1) {
                ServerReportStringBrick nextBrick = bricks.get(bricks.indexOf(br) + 1);
                if (nextBrick.getMessage().length() > 0) {
                    char nextChar = nextBrick.getMessage().charAt(0);
                    if (Character.isDigit(nextChar) || Character.isLetter(nextChar)) {
                        sb.append(" ");
                    }
                }
            }
        }
        return sb.toString();
    }

    private void createSimpleCell(PdfDocCurrentContext context,
                                  float xPosition, float yPosition,
                                  float width, float height, int red, int green, int blue) throws IOException {
        context.getPageContentStream().setNonStrokingColor(red, green, blue);
        context.getPageContentStream().addRect(xPosition, yPosition, width, height);
        context.getPageContentStream().fill();
        context.getPageContentStream().setStrokingColor(156, 194, 229);
        context.getPageContentStream().addRect(xPosition, yPosition, width, height);
        context.getPageContentStream().stroke();
    }

    private void fillSimpleCell(PdfDocCurrentContext context,
                                float xPosition, float yPosition,
                                String text, Color color, float fontSize) throws IOException {
        context.getPageContentStream().beginText();
        context.getPageContentStream().newLineAtOffset(xPosition, yPosition);
        context.getPageContentStream().setNonStrokingColor(color);
        context.getPageContentStream().setFont(getPdfFonts().getBasic(), fontSize);
        context.getPageContentStream().showText(text);
        context.getPageContentStream().endText();
    }

    private void fillSimpleCell(PdfDocCurrentContext context,
                                float xPosition, float yPosition,
                                String text, Color color, float fontSize, float maxWidth) throws IOException {

        List<String> list = sliceText(text, fontSize, maxWidth);
        for (int i = 0; i < list.size(); i++) {
            fillSimpleCell(context, xPosition + ((maxWidth + LEFT_TABLE_CELL_CONTENT_PADDING * 2) / 2)
                    - getWidthOfText(fontSize, list.get(i)) / 2,
                yPosition - i * fontSize * LINE_INTERVAL, list.get(i), color, fontSize);
        }
    }


    private void correctYPosition(PdfDocCurrentContext context, float fontSize, float xposition) {
        float lineHeight = fontSize * PdfConstants.LINE_INTERVAL;
        if (xposition == PdfConstants.LEFT_INDENT
            && (context.getCurrentNextPositionY() - lineHeight - 4 * PdfConstants.PDF_GAP)
            <= context.getCurrentPage().getMediaBox().getLowerLeftY()) {
            context.setCurrentNextPositionY(context.getCurrentNextPositionY() - lineHeight);
        }
    }

    private void mergeHardwareConfigurationTables(ServerReportParagraph paragraph) {
        for (int i = 0; i < paragraph.size() - 1; i++) {
            if (paragraph.get(i).getDetails() != null && !paragraph.get(i).getDetails().isEmpty() && !paragraph.get(i).isMerged()) {
                for (Map.Entry<String, Map<String, String>> entry1 : paragraph.get(i).getDetails().entrySet()) {
                    String key1 = entry1.getKey();
                    for (int j = i + 1; j < paragraph.size(); j++) {
                        if (paragraph.get(j).getDetails() != null && !paragraph.get(j).getDetails().isEmpty()) {
                            for (Map.Entry<String, Map<String, String>> entry2 : paragraph.get(j).getDetails().entrySet()) {
                                String key2 = entry2.getKey();
                                if (key1.equals(key2)) {
                                    paragraph.get(i).getDetails().get(key1).putAll(paragraph.get(j).getDetails().get(key2));
                                    paragraph.get(j).setMerged(true);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private float getWidthOfText(float textSize, String visibleText) throws IOException {
        return textSize * (getPdfFonts().getBasic().getStringWidth(visibleText)) / 1000f;
    }

    private float getHeightOfText(int numberOfLines, float fontSize) throws IOException {
        return numberOfLines * LINE_INTERVAL * fontSize;
    }

    private List<String> sliceText(String visibleText, float textSize, float maxWidth) throws IOException {
        List<String> textLines = new ArrayList<>();
        String[] splitLines = visibleText.split(System.lineSeparator());
        for (String rawLine : splitLines) {
            String[] split = rawLine.split(" ");
            StringBuilder line = new StringBuilder();
            for (String word : split) {
                if (getWidthOfText(textSize, line.toString().concat(word)) < maxWidth) {
                    line.append(word);
                    line.append(" ");
                } else {
                    textLines.add(line.toString());
                    line = new StringBuilder();
                    line.append(word);
                    line.append(" ");
                }
            }
            textLines.add(line.toString());
        }
        return normalizeText(textLines, textSize, maxWidth);
    }

    private List<String> normalizeText(List<String> text, float textSize, float maxWidth) throws IOException {
        List<String> normalizeText = new ArrayList<>();

        for (String word : text) {
            if (getWidthOfText(textSize, word) < maxWidth) {
                normalizeText.add(word);
            } else {
                List<String> wordsAfterSplit = new ArrayList<>();
                char[] letters = word.toCharArray();
                StringBuilder stringBuilder = new StringBuilder();
                for (char letter : letters) {
                    if (getWidthOfText(textSize, stringBuilder.toString() + letter) < maxWidth) {
                        stringBuilder.append(letter);
                    } else {
                        wordsAfterSplit.add(stringBuilder.toString());
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(letter);
                    }
                }
                if (!StringUtils.isNullOrEmpty(stringBuilder.toString())) {
                    wordsAfterSplit.add(stringBuilder.toString());
                }
                normalizeText.addAll(wordsAfterSplit);
            }
        }

        for (int i = 0; i < normalizeText.size(); i++) {
            if (StringUtils.isNullOrEmpty(normalizeText.get(i)) || normalizeText.get(i).equals(" ")) {
                normalizeText.remove(i);
                i--;
            }
        }

        return normalizeText;
    }

    public PdfFonts getPdfFonts() {
        return pdfFonts;
    }

    public void setPdfFonts(PdfFonts pdfFonts) {
        this.pdfFonts = pdfFonts;
    }

    /**
     * Prepares list of target headers.
     *
     * @param targetDatabaseHeads target database headers
     * @return list of headers
     */
    public List<String> prepareToParagraphList(String... targetDatabaseHeads) {
        StringBuilder result = new StringBuilder("");
        for (String s : targetDatabaseHeads) {
            if (!result.toString().equals("")) {
                result.append("\n");
            }
            if (s != null) {
                result.append(s);
            }
        }
        return Arrays.asList(result.toString().split("\n|(, )"));
    }

    public static String normilizePdfText(String pdfReportHeader) {
        String decomposed = Normalizer.normalize(pdfReportHeader, Normalizer.Form.NFD).replaceAll("\r", "");
        return decomposed.replaceAll("[^\\x00-\\x7F]", "?");
    }
}
