package io.topdf.createPDFdocument;

import com.amazon.diagnostics.logger.MessageType;
import com.amazon.sct.common.progress.TaskProgressProperty;
import com.amazon.sct.logger.Logger;
import com.amazon.sct.service.callback.ServiceCallback;
import com.amazon.sct.task.AwsTask;
import com.amazon.sct.util.StringUtils;
import java.util.concurrent.ExecutionException;
import javafx.concurrent.Worker;

public class CommonTaskLauncher {

    public static <T> void run(AwsTask<T> baseTask, TaskProgressProperty taskProgressProperty, ServiceCallback<T> callback, String name) {
        if (taskProgressProperty != null) {
            baseTask.setAborted(taskProgressProperty.isAborted());
            if (StringUtils.isNullOrEmpty(baseTask.messageProperty().get())) {
                baseTask.updateMessage(taskProgressProperty.messageProperty().get());
            }
            taskProgressProperty.messageProperty().bind(baseTask.messageProperty());
            taskProgressProperty.progressProperty().bind(baseTask.progressProperty());
            taskProgressProperty.setVisibleAbort(taskProgressProperty.getHaveCancel());
        }
        baseTask.stateProperty().addListener((observableValue, oldState, newState) -> {
            Logger.GENERAL.write(MessageType.DEBUG, name + ": " + oldState + " -> " + newState);
            T result = null;
            if (newState == Worker.State.SUCCEEDED || newState == Worker.State.FAILED) {
                try {
                    result = baseTask.get();
                } catch (InterruptedException | ExecutionException e) {
                    Logger.GENERAL.writeError(e);
                } finally {
                    if (callback != null) {
                        callback.call(result, baseTask.getException());
                    }
                }
            }

        });
        Thread thread = new Thread(baseTask);
        thread.setName(!StringUtils.isNullOrEmpty(name) ? name : baseTask.getClass().getSimpleName());
        thread.start();
    }
}
