package io.topdf.createPDFdocument;

import com.amazon.sct.service.report.generator.ReportGenerator;
import com.amazon.sct.service.report.generator.utils.pdf.PdfConstants;
import java.io.IOException;
import org.apache.pdfbox.pdmodel.PDDocument;

public abstract class PdfBaseReportGenerator implements ReportGenerator {
    //@todo Task 12185
    private PdfConstants pdfConstants;

    public PDDocument createDocument() throws IOException {
        PDDocument document = new PDDocument();
        pdfConstants = new PdfConstants(document);
        return  document;
    }

    public PdfConstants getPdfConstants() {
        return pdfConstants;
    }
}
