package io.topdf;

import com.amazon.diagnostics.notifications.NotificationInformer;
import com.amazon.sct.App;
import com.amazon.sct.AppInitializer;
import com.amazon.sct.common.progress.TaskProgressProperty;
import com.amazon.sct.util.PercentUtil;
import com.amazon.sct.util.event.AwsEvent;
import com.amazon.sct.util.event.AwsEventType;
import com.amazon.sct.util.event.ProjectEventBus;
import com.amazon.sct.view.cassandraclonewizard.CloneDCWizardView;
import com.amazon.sct.view.control.HyperlinkAws;
import com.amazon.sct.view.control.clonedc.ShowLogView;
import com.amazon.sct.view.util.GuiUtils;
import java.text.MessageFormat;
import javafx.application.Platform;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.ImageView;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.Window;
import javafx.util.Pair;

public class LoadingDialogView extends Alert implements TaskProgressProperty {
    @FXML
    private ButtonBar buttonBar;

    private static final String SOURCE_METADATA_VIEW_ID = "sourceMetadataView";
    private static final String TARGET_METADATA_VIEW_ID = "targetMetadataView";
    private static final float DEFAULT_WIDTH = 500;

    private String parentNodeId;
    private boolean aborted;
    private LoadingDialogContentView loadingDialogContentView = new LoadingDialogContentView();
    private SimpleBooleanProperty haveCancel = new SimpleBooleanProperty(this, "haveCancel", false);
    private SimpleBooleanProperty haveProgressBar = new SimpleBooleanProperty(this, "haveProgressBar", true);


    private final ImageView IMAGE_VIEW = new ImageView(this.getClass().getResource("gear32.gif").toString());
    private int instanceCount = 0;

    public LoadingDialogView(String parentNodeId, Modality modality) {
        this(modality);
        this.parentNodeId = parentNodeId;
    }

    public LoadingDialogView(Stage stage, Modality modality) {
        this(modality);
        initOwner(stage);
        setPosition();

        if (getOwner() != null && getOwner() == CloneDCWizardView.getWizardStage()) {
            HyperlinkAws showLogLink = new HyperlinkAws("Show Log");
            showLogLink.setOnAction(e -> onShowLog());
            ButtonBar.setButtonData(showLogLink, ButtonBar.ButtonData.LEFT);

            Button button = new Button();
            button.setVisible(false);

            buttonBar = (ButtonBar) getDialogPane().getChildren().stream().filter(p -> p instanceof ButtonBar).findFirst().orElse(null);
            buttonBar.getButtons().addAll(showLogLink, button);
        }
    }

    public LoadingDialogView(Modality modality) {
        super(AlertType.CONFIRMATION);
        setHeaderText(null);
        setGraphic(IMAGE_VIEW);
        getButtonTypes().clear();
        setResult(ButtonType.CLOSE);
        initModality(modality);
        initStyle(StageStyle.UNDECORATED);
        getDialogPane().setStyle("-fx-padding: 3 0 0 0;-fx-border-color: darkgrey;-fx-border-width: 2px;");
        TextChangeListener textChangeListener = new TextChangeListener();
        loadingDialogContentView.getlTitle().textProperty().bind(titleProperty());
        loadingDialogContentView.getlContent().textProperty().bind(contentTextProperty());

        loadingDialogContentView.getlContent().textProperty().addListener(textChangeListener);
        loadingDialogContentView.getlTitle().textProperty().addListener(textChangeListener);
        loadingDialogContentView.getProgressBar().progressProperty().addListener((observable, oldValue, newValue) -> {
            loadingDialogContentView.getlProgress().setText(PercentUtil.formatCustom((100 * (double) newValue), "0") + "%");
        });

        loadingDialogContentView.getlStop().visibleProperty().bind(haveCancel);
        loadingDialogContentView.getHBoxProgress().visibleProperty().bind(haveProgressBar);

        //lTitle.setMinWidth(Region.USE_PREF_SIZE);
        //lContent.setMinWidth(Region.USE_PREF_SIZE);

        showingProperty().addListener((observable, oldValue, newValue) -> {
            if(newValue){
                GuiUtils.setDialogToOwnerCenter(this);
            }
        });

        getDialogPane().setContent(loadingDialogContentView);
        updateWidth();
    }

    @Override
    public DoubleProperty progressProperty() {
        return getProgressBar().progressProperty();
    }

    @Override
    public javafx.beans.property.StringProperty messageProperty() {
        return contentTextProperty();
    }

    public void slightShow(String title, String content) {
        if (instanceCount == 0) {
            show(title, content);
        } else {
            instanceCount++;
        }
    }

    private class TextChangeListener implements ChangeListener<String> {
        @Override
        public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
            updateWidth();
        }
    }

    private void updateWidth() {
        getDialogPane().setMaxWidth(DEFAULT_WIDTH);
        getDialogPane().setMinWidth(DEFAULT_WIDTH);
        getDialogPane().setPrefWidth(DEFAULT_WIDTH);
       setWidth(DEFAULT_WIDTH);

        /*double textWidth = DEFAULT_WIDTH;

        if (getHaveCancel()) {
            textWidth += 50.0;
        }
        if (getHaveCancel() && getHaveProgressBar()) {
            textWidth = PROGRESS_BAR_FIXED_WIDTH;
        }
        loadingDialogContentView.getvBox().setMinWidth(textWidth); */
    }

         /*
            float imageSize = (float) IMAGE_VIEW.getImage().getWidth();
            float contextTextWidth = GuiUtils.computeStringWidth(getContentText(), loadingDialogContentView.getlContent().getFont());
            float titleTextWidth = GuiUtils.computeStringWidth(getTitle(), loadingDialogContentView.getlTitle().getFont());
            float textWidth = Math.max(contextTextWidth, titleTextWidth) + 50;
            if (getHaveCancel()) {
                textWidth += 50;
            }
            if (getHaveCancel() && getHaveProgressBar()) {
                textWidth = PROGRESS_BAR_FIXED_WIDTH;
            }

            setWidth(textWidth + imageSize);
            getDialogPane().setMinWidth(getWidth() + 4 - 0.5);//javafx bug fix 2px * 2 = 4

            loadingDialogContentView.getvBox().setMinWidth(vBoxMinWidth);

            // getDialogPane().setContent(box);
            Window owner = getOwner();
            if (owner == null) {
                owner = App.getMainStage();
            }
            if (owner != null) {
                setX((owner.getX() + owner.getWidth() / 2 - getWidth() / 2));
                setY(owner.getY() + owner.getHeight() / 2 - getHeight() / 2);
                if (parentNodeId != null) {
                    Node node = owner.sceneProperty().get().lookup("#" + parentNodeId);
                    if (node != null && node.isVisible()) {
                        double x = node.localToScreen(node.getLayoutBounds()).getMinX();
                        double y = node.localToScreen(node.getLayoutBounds()).getMinY();
                        double width = node.getLayoutBounds().getWidth();
                        double height = node.getLayoutBounds().getHeight();
                        ObservableList<Screen> screensForRectangle = Screen.getScreensForRectangle(x, y, width, height);
                        if (!screensForRectangle.isEmpty() && screensForRectangle.get(0).getBounds().contains(x, y)) {

                            double mid = ((owner.getX() + owner.getWidth() / 2));
                            double offset = (owner.getWidth() / 2) * 0.7;
                            if (x <= mid) {
                                setX(mid - offset - loadingDialogContentView.getvBox().getMinWidth() / 2);
                            }
                            if (x > mid) {
                                setX(mid + offset - loadingDialogContentView.getvBox().getMinWidth() / 2);
                            }
                            setY(y + height / 2 - getHeight() / 2);
                        } else {
                            setDefaultXY();
                        }
                    } else {
                        setDefaultXY();
                    }
                } else {
                    setDefaultXY();
                }
            }

        }
    } */

    public void showDialog() {
        show(getTitle(), getContentText(), getHaveCancel(), getHaveProgressBar());
    }

    public void show(String title, String content) {
        show(title, content, false, true);
    }

    public void show(String title, String content, boolean haveCancel, boolean haveProgressBar) {
        resetViewProperties();
        setHaveProgressBar(haveProgressBar);
        setHaveCancel(haveCancel);
        contentTextProperty().unbind();
        setTitle(title);
        setContentText(content);
        instanceCount++;

        if (App.getMainStage() != null && getOwner() == null) {
            initOwner(App.getMainStage());
        }

        if (!isShowing()) {
            addListeners();

            show();
        }
    }

    private void addListeners() {
        loadingDialogContentView.getlStop().setOnMouseClicked(event -> {
            ProjectEventBus.getInstance().fire(AwsEventType.STOP_EVENT, new AwsEvent(App.APPLICATION_TITLE));
            onAbort();
        });
    }

    private void resetViewProperties() {
        setAborted(false);
        loadingDialogContentView.getlStop().setDisable(false);
        loadingDialogContentView.resetProgressBar();
    }

    private class LabelTextChangeListener implements ChangeListener<String> {
        @Override
        public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
            setPosition();
        }
    }

    private void setPosition() {
        if (getDialogPane().getScene() != null) {
            getDialogPane().getScene().getWindow().sizeToScene();
            if (parentNodeId != null) {
                Window owner = getOwner();
                if (owner == null) {
                    owner = App.getMainStage();
                }
                Node node = owner.sceneProperty().get().lookup("#" + parentNodeId);
                if (node != null && node.isVisible()) {
                    double x = node.localToScreen(node.getLayoutBounds()).getMinX();
                    double y = node.localToScreen(node.getLayoutBounds()).getMinY();
                    double width = node.getLayoutBounds().getWidth();
                    double height = node.getLayoutBounds().getHeight();
                    ObservableList<Screen> screensForRectangle = Screen.getScreensForRectangle(x, y, width, height);
                    if (!screensForRectangle.isEmpty() && screensForRectangle.get(0).getBounds().contains(x, y)) {
                        if (SOURCE_METADATA_VIEW_ID.equals(parentNodeId)) {
                            setX(x + width - getDialogPane().getWidth() / 2);
                        } else {
                            setX(x - getDialogPane().getWidth() / 2);
                        }
//                        setY(y + height / 2 - getHeight() / 2);
                        setY(owner.getY() + owner.getHeight() / 2);

                    } else {
                        setDefaultXY();
                    }
                } else {
                    setDefaultXY();
                }
            } else {
                setDefaultXY();
            }
        }
    }

    private void setDefaultXY() {
        Window owner = getOwner();
        if (owner == null) {
            owner = App.getMainStage();
        }
        setX(owner.getX() + owner.getWidth() / 2 - getWidth() / 2);
        setY(owner.getY() + owner.getHeight() / 2);
    }

    public void show(String title, String content, String parentNodeId, boolean haveCancel, boolean haveProgressbar) {
        setParentNodeId(parentNodeId);
        show(title, content, haveCancel, haveProgressbar);
    }

    public void show(String title, String content, String parentNodeId) {
        setParentNodeId(parentNodeId);
        show(title, content);
    }

    public void hideDialog() {
        if (instanceCount != 0) {
            instanceCount--;
        }
        if (instanceCount == 0) {
            contentTextProperty().unbind();
            hide();
            resetViewProperties();
        }
    }

    public void setParentNodeId(String parentNodeId) {
        this.parentNodeId = parentNodeId;
    }

    public void setStopEvent(EventHandler<javafx.scene.input.MouseEvent> stopEvent) {
        loadingDialogContentView.getlStop().setOnMouseClicked(event -> {
            stopEvent.handle(event);
            onAbort();
        });
    }

    private void onAbort() {
        if (getOwner().equals(App.getMainStage())) {
            NotificationInformer.addNotification(MessageFormat.format(AppInitializer.resourceBundle.getString("ui.loading.dialog.abort.tooltip"), getTitle() + "/" + getContentText()));
        }
        contentTextProperty().unbind();
        loadingDialogContentView.getlStop().setDisable(true);
        setContentText(AppInitializer.resourceBundle.getString("ui.loading.dialog.wait.abort"));
        setAborted(true);
    }

    private void onShowLog() {
        ShowLogView showLogView = new ShowLogView(GuiUtils.getLogs());
        showLogView.initOwner(getOwner());
        showLogView.show();
    }

    public boolean getHaveCancel() {
        return haveCancel.get();
    }

    public SimpleBooleanProperty haveCancelProperty() {
        return haveCancel;
    }

    public void setHaveCancel(boolean haveCancel) {
        this.haveCancel.set(haveCancel);
    }


    public boolean getHaveProgressBar() {
        return haveProgressBar.get();
    }

    public SimpleBooleanProperty haveProgressBarProperty() {
        return haveProgressBar;
    }

    public void setHaveProgressBar(boolean haveProgressBar) {
        this.haveProgressBar.set(haveProgressBar);
    }

    public LoadingDialogContentView getLoadingDialogContentView() {
        return loadingDialogContentView;
    }

    public void setLoadingDialogContentView(LoadingDialogContentView loadingDialogContentView) {
        this.loadingDialogContentView = loadingDialogContentView;
    }

    public ProgressBar getProgressBar() {
        return loadingDialogContentView.getProgressBar();
    }

    public boolean isAborted() {
        return aborted;
    }

    @Override
    public void setVisibleAbort(boolean value) {
        this.setHaveCancel(value);
        updateWidth();
    }

    public void setAborted(boolean aborted) {
        this.aborted = aborted;
    }

    public void setProgressToTask(Pair<String, Double> pair) {
        Platform.runLater(() -> {
            setContentText(pair.getKey());
            getProgressBar().setProgress(pair.getValue());
        });
    }
}
