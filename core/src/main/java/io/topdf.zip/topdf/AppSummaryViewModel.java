package io.topdf;

import com.amazon.sct.handler.SaveReportToCSVHandler;
import com.amazon.sct.model.report.input.PdfInputReportData;
import com.amazon.sct.model.report.result.ui.AppConversionSummaryTabModel;
import com.amazon.sct.model.report.type.ReportType;
import java.io.IOException;
import java.util.Collections;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;

public class AppSummaryViewModel {

    private ObjectProperty<AppConversionSummaryTabModel> appSummaryModel = new SimpleObjectProperty<>(this, "appSummaryModel");

    private BooleanProperty noContentLabelVisible = new SimpleBooleanProperty(this, "noContentLabelVisible", false);

    public AppSummaryViewModel() {
    }

    public AppConversionSummaryTabModel getAppSummaryModel() {
        return appSummaryModel.get();
    }

    public ObjectProperty<AppConversionSummaryTabModel> appSummaryModelProperty() {
        return appSummaryModel;
    }

    public void setAppSummaryModel(AppConversionSummaryTabModel appSummaryModel) {
        this.appSummaryModel.set(appSummaryModel);
        setNoContentLabelVisible(false);
    }

    public void doOnNoConversionObject() {
        this.appSummaryModel.set(null);
        setNoContentLabelVisible(true);
    }

    public void saveToPdf(javafx.stage.Window win) {
        new SaveReportToPdfFileHandler().saveReportToPdfFile(win, new PdfInputReportData(getAppSummaryModel(), ReportType.PDF_APP_CONVERSION),
                getAppSummaryModel().getTargetDBName(), null);
    }

    public void saveToCsv(javafx.stage.Window win) throws IOException {
        // new SaveReportToCSVHandler().saveModelToCSV(win, getAppSummaryModel().getTargetDB(), getAppSummaryModel());
        new SaveReportToCSVHandler().saveModelToCSV(
            win, getAppSummaryModel().getTargetDBName()
            , Collections.singletonList(getAppSummaryModel()),
            false, ReportType.CSV_APP_CONVERSION, null);
    }

    public boolean getNoContentLabelVisible() {
        return noContentLabelVisible.get();
    }

    public BooleanProperty noContentLabelVisibleProperty() {
        return noContentLabelVisible;
    }

    public void setNoContentLabelVisible(boolean noContentLabelVisible) {
        this.noContentLabelVisible.set(noContentLabelVisible);
    }
}
