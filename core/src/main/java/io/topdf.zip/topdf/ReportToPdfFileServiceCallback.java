package io.topdf;

import com.amazon.sct.App;
import com.amazon.sct.AppInitializer;
import com.amazon.sct.logger.Logger;
import com.amazon.sct.service.callback.ServiceCallback;
import com.amazon.sct.util.CrossPlatformUtils;
import com.amazon.sct.view.util.GuiUtils;
import java.io.File;
import java.util.Optional;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Window;

public class ReportToPdfFileServiceCallback implements ServiceCallback<Void> {

    private File file;
    private boolean needOpenResult;

    public ReportToPdfFileServiceCallback(File file, boolean needOpenResult) {
        this.file = file;
        this.needOpenResult = needOpenResult;
    }

    @Override
    public void call(Void res, Throwable exception) {
        if(exception == null) {
            try {
                if (needOpenResult) {
                    CrossPlatformUtils.openFileIfItPossible(file);
                }
            } catch (Exception exc) {
                Logger.GENERAL.writeError(exc);
            }
        } else {
            Logger.UI.writeError(exception);
            GuiUtils.showErrorAlert(AppInitializer.resourceBundle.getString("ui.file.save.error"),
                    AppInitializer.resourceBundle.getString("ui.error.happen.during.save.pdf.file"), exception.getMessage(), App.getMainStage());
        }
    }

    public static Optional<ButtonType> showErrorAlert(String title, String header, String text, Window owner) {
        Alert alert = createAlert(Alert.AlertType.ERROR, title, header, text, owner);
        return alert.showAndWait();
    }


  }


