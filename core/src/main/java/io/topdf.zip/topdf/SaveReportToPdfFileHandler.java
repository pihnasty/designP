package io.topdf;


import java.io.File;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class SaveReportToPdfFileHandler {

    public SaveReportToPdfFileHandler() {
    }

    public void saveReportToPdfFile(javafx.stage.Window win, PdfInputReportData pdfInputReportData, String targetDBName, File determinedFile) {
        LoggerUIUtil.logHandlerActionInfo(getClass().getSimpleName(), "Save to PDF is starting...");
        File file = determinedFile != null ? determinedFile : GuiUtils.getPDFFile(win, targetDBName);

        if (file != null) {
            ReportToPdfFileServiceCallback callback = new ReportToPdfFileServiceCallback(file, determinedFile == null);
            LoadingDialogView loadingDialog = new LoadingDialogView((Stage) win, Modality.WINDOW_MODAL);
            ReportToPdfFileTask reportToPdfFileTask = new ReportToPdfFileTask(pdfInputReportData, file);
            loadingDialog.show(AppInitializer.resourceBundle.getString("ui.app.saving.pdf.report"), "");

            CommonTaskLauncher.run(reportToPdfFileTask, loadingDialog, (result, exception) -> {
                loadingDialog.hideDialog();
                callback.call(null, reportToPdfFileTask.getException());
            }, "ReportToPdfFileTask");
        }
    }



    public static File getPDFFile(javafx.stage.Window win, String fileName) {
        FileChooser fileChooser = new FileChooser();

        File file = new File(SettingsProvider.getDefaultProjectSettings().get(Settings.Keys.DEFAULT_PROJECT_PATH));

        if (file.exists()) {
            fileChooser.setInitialDirectory(file);
        }

        FileChooser.ExtensionFilter extFilter =
            new FileChooser.ExtensionFilter(AppInitializer.resourceBundle.getString("ui.pdf.files.pdf"),
                AppInitializer.resourceBundle.getString("ui.pdf.ext"));
        fileChooser.getExtensionFilters().add(extFilter);
        if (fileName != null) {
            fileChooser.setInitialFileName(fileName);
        }
        return fileChooser.showSaveDialog(win);
    }

}
