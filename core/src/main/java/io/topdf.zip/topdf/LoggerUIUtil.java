package io.topdf;

import com.amazon.sct.logger.Logger;
import com.amazon.sct.model.MetadataModel;

/**
 * LoggerUIUtil
 */
public class LoggerUIUtil {
    private static final String DELIMITER = ". ";
    /**
     * Logs handler action with selected node and additionMessage
     *
     * @param handlerName      = name of a calling class
     * @param selectedMetadata = selected node on a metadata tree
     * @param additionMessage  = any addition message
     */
    public static void logHandlerActionInfo(String handlerName, MetadataModel selectedMetadata, String additionMessage) {
        String message = getSimpleMessage(getHandlerName(handlerName), selectedMetadata)
            + DELIMITER
            + additionMessage;
        log(message);
    }

    /**
     * Logs handler action with selected node
     *
     * @param handlerName      = name of a calling class
     * @param selectedMetadata = selected node on a metadata tree
     */
    public static void logHandlerActionInfo(String handlerName, MetadataModel selectedMetadata) {
        log(getSimpleMessage(getHandlerName(handlerName), selectedMetadata));
    }

    /**
     * Logs handler action additionMessage
     *
     * @param handlerName     = name of a calling class
     * @param additionMessage = any addition message
     */
    public static void logHandlerActionInfo(String handlerName, String additionMessage) {
        String message = getCalledHandlerMessage(handlerName)
            + DELIMITER
            + additionMessage;
        log(message);
    }

    /**
     *
     * @param scope
     * @param handlerName
     */
    public static void logHandlerActionWithScopeInfo(String scope, String handlerName) {
        String message = scope
            + ": "
            + getCalledHandlerMessage(handlerName);
        log(message);
    }

    /*/

     */
    public static void logHandlerActionWithScopeInfo(String scope, String handlerName, String additionMessage) {
        String message = scope
            + ": "
            + getCalledHandlerMessage(handlerName)
            + DELIMITER
            + additionMessage;
        log(message);
    }

    /**
     * Logs only handler action
     *
     * @param handlerName = name of a calling class
     */
    public static void logHandlerActionInfo(String handlerName) {
        log(getCalledHandlerMessage(handlerName));
    }

    /**
     * Gets full name of selectedMetadata
     *
     * @param selectedMetadata = selected node
     * @return full name of selectedMetadata or "empty" if selectedMetadata is null
     */
    public static String getSelectedMetadataFullName(MetadataModel selectedMetadata) {
        if (selectedMetadata != null) {
            if (selectedMetadata.getFullName() != null) {
                return "[" + selectedMetadata.getFullName() + "]";
            }
            return "[node name is undefined]";
        }

        return "[is not selected]";
    }

    /**
     * Checks whether handlerName contains a dot in case of full class name
     *
     * @param handlerName = name of a calling class
     * @return simple class name
     */
    public static String getHandlerName(String handlerName) {
        if (handlerName.contains(".")) {
            return handlerName.substring(handlerName.lastIndexOf('.') + 1);
        }

        return handlerName;
    }

    private static void log(String message) {
        Logger.UI.writeInfo(message);
    }

    private static String getSimpleMessage(String handlerName, MetadataModel selectedMetadata) {
        return getCalledHandlerMessage(handlerName)
            + ", selected metadata: "
            + getSelectedMetadataFullName(selectedMetadata);
    }

    private static String getCalledHandlerMessage(String handlerName) {
        return "Called [" + handlerName + "]";
    }
}
