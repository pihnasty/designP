package io.topdf;

import com.amazon.sct.model.report.input.PdfInputReportData;
import com.amazon.sct.model.report.result.Saved;
import com.amazon.sct.service.report.ReportService;
import java.io.File;

public class ReportToPdfFileTask extends BaseTask<Void> {

    private final File file;
    private final PdfInputReportData pdfInputReportData;

    public ReportToPdfFileTask(PdfInputReportData pdfInputReportData, File file) {
        this.pdfInputReportData = pdfInputReportData;
        this.file = file;
    }

    @Override
    protected Void call() throws Exception {
        updateMessage("Save report to pdf file "+file);
        //PdfDocumentService pdfDocumentManager = PdfDocumentService.getInstance();
        //pdfDocumentManager.saveReportToPdfFile(reportModel, file);
        ((Saved) ReportService.getInstance().getReport(pdfInputReportData.getReportType(), pdfInputReportData)).saveTo(file);
        updateMessage("Report is saved to file "+file);
        return  null;
    }
}
