package io.task;

import java.io.Serializable;
import java.util.UUID;

public abstract class Command implements Serializable, Cloneable{
    private String projectId;
    private String commandId;
    private UUID replaceCommandId;

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getCommandId() {
        return commandId;
    }

    public void setCommandId(String commandId) {
        this.commandId = commandId;
    }

    public UUID getReplaceCommandId() {
        return replaceCommandId;
    }

    public void setReplaceCommandId(UUID replaceCommandId) {
        this.replaceCommandId = replaceCommandId;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder(getClass().getSimpleName()).append("{");
        sb.append("projectId='").append(projectId).append('\'');
        sb.append('}');
        return sb.toString();
    }

    @Override
    public Command clone() throws CloneNotSupportedException {
        return (Command)super.clone();
    }
}
