package io.task;

import com.amazon.sct.common.beans.OperationType;
import com.amazon.sct.facade.core.ExecutionState;
import com.amazon.sct.facade.core.ProjectStorage;
import com.amazon.sct.facade.model.commands.OpenProjectCommand;
import com.amazon.sct.facade.tasks.Task;
import com.amazon.sct.model.utils.FileNames;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.nio.file.Path;

public class OpenProjectTask extends Task<OpenProjectCommand> {

    @JsonCreator
    public OpenProjectTask(@JsonProperty("command") OpenProjectCommand command) {
        super(command);
    }

    @Override
    public OperationType getOperationType() {
        return OperationType.Load_Project;
    }

    @Override
    public boolean isValid() {
        return true;
    }

    @Override
    public void execute(ExecutionState executionState) {
        executionState.checkCurrentProjectId(null);
        executionState.checkProjectExists(getProjectId());
        Path projectFilePath = ProjectStorage.getProjectDirectory(getProjectId())
            .resolve(ProjectStorage.SAVED_DIR)
            .resolve(FileNames.PROJECT_FILE_NAME);
        executionState.init(projectFilePath, getProjectId(), getTaskProgress());
    }
}
