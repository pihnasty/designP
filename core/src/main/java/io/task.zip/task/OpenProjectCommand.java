package io.task;

public class OpenProjectCommand extends Command {
}
