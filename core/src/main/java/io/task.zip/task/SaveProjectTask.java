package io.task;

import com.amazon.sct.common.beans.OperationType;
import com.amazon.sct.facade.core.ExecutionState;
import com.amazon.sct.facade.core.ProjectStorage;
import com.amazon.sct.facade.model.commands.SaveProjectCommand;
import com.amazon.sct.facade.tasks.Task;
import com.amazon.sct.facade.utils.ProjectSaver;
import com.amazon.sct.model.v2.Project;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.nio.file.Path;

public class SaveProjectTask extends Task<SaveProjectCommand> {
    @JsonCreator
    public SaveProjectTask(@JsonProperty("command") SaveProjectCommand command) {
        super(command);
    }

    @Override
    public OperationType getOperationType() {
        return OperationType.Save_Project;
    }


    @Override
    public boolean isValid() {
        return getProjectId() != null && !getProjectId().isEmpty();
    }

    @Override
    public void execute(ExecutionState executionState) {
        executionState.checkCurrentProjectId(getProjectId());
        executionState.checkProjectExists(getProjectId());
        Project project = executionState.getProject();
        if (project != null) {
            Path dest = ProjectStorage.getProjectDirectory(getProjectId()).resolve(ProjectStorage.SAVED_DIR);
            ProjectSaver.save(project, dest, getTaskProgress());
        }
    }

    @Override
    public void saveState(ExecutionState executionState) {
    }
}
